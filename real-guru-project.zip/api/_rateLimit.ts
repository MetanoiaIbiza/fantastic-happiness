/**
 * Simple in-memory sliding-window rate limiter.
 *
 * This is good enough for early traffic. It runs per warm Edge instance,
 * which means limits reset when the function cold-starts and can be
 * bypassed by a determined attacker. Good enough for MVP.
 *
 * For real traffic, swap this for Upstash Ratelimit:
 *   import { Ratelimit } from "@upstash/ratelimit";
 *   import { Redis } from "@upstash/redis";
 *   const rl = new Ratelimit({
 *     redis: Redis.fromEnv(),
 *     limiter: Ratelimit.slidingWindow(20, "1 m")
 *   });
 *   const { success, reset } = await rl.limit(ip);
 *
 * Upstash has a free tier. 5 min setup.
 */

type Bucket = number[];
const buckets = new Map<string, Bucket>();

export interface RateLimitOptions {
  /** Max requests allowed inside the window */
  max: number;
  /** Window size in milliseconds */
  windowMs: number;
}

export interface RateLimitResult {
  ok: boolean;
  /** Seconds to wait before retrying (0 if ok) */
  retryAfter: number;
  /** Requests remaining in this window */
  remaining: number;
}

export function rateLimit(
  key: string,
  opts: RateLimitOptions
): RateLimitResult {
  const now = Date.now();
  const cutoff = now - opts.windowMs;

  const hits = (buckets.get(key) || []).filter((t) => t > cutoff);

  if (hits.length >= opts.max) {
    const oldest = hits[0];
    const retryAfter = Math.max(1, Math.ceil((oldest + opts.windowMs - now) / 1000));
    buckets.set(key, hits);
    return { ok: false, retryAfter, remaining: 0 };
  }

  hits.push(now);
  buckets.set(key, hits);

  // Opportunistic GC to keep memory bounded.
  if (buckets.size > 5000) {
    for (const [k, v] of buckets) {
      if (v.every((t) => t <= cutoff)) buckets.delete(k);
    }
  }

  return { ok: true, retryAfter: 0, remaining: opts.max - hits.length };
}

/** Pull the caller's IP out of the request in a runtime-agnostic way. */
export function getClientIp(req: Request): string {
  const xff = req.headers.get("x-forwarded-for");
  if (xff) {
    const first = xff.split(",")[0]?.trim();
    if (first) return first;
  }
  return (
    req.headers.get("x-real-ip") ||
    req.headers.get("cf-connecting-ip") ||
    req.headers.get("x-vercel-forwarded-for") ||
    "unknown"
  );
}
