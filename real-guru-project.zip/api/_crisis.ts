import type { GuruResponseT } from "./_schema";

/**
 * Defense-in-depth crisis detection.
 *
 * The LLM is also instructed to route to safety, but we never want to rely
 * only on that. This runs BEFORE the LLM call. If it trips, we return the
 * canned Crisis Card response and never send the user's text to the model.
 *
 * Keep this list broad rather than narrow. False positives here are fine —
 * a user who is not in crisis and receives a gentle resource card will be
 * mildly surprised. A user who IS in crisis and gets roasted is a disaster.
 */

const CRISIS_PATTERNS: RegExp[] = [
  /\bkill\s*myself\b/i,
  /\bkill\s*me\b/i,
  /\bkilling\s*myself\b/i,
  /\bend\s*(it|my\s*life|things)\s*(all)?\b/i,
  /\bwant\s*to\s*die\b/i,
  /\bi\s*(want|wanna)\s*die\b/i,
  /\b(suicide|suicidal)\b/i,
  /\b(cut|cutting)\s*myself\b/i,
  /\bhurt(ing)?\s*myself\b/i,
  /\bself[-\s]?harm\b/i,
  /\bdisappear\s*forever\b/i,
  /\bno\s*reason\s*to\s*live\b/i,
  /\bnothing\s*to\s*live\s*for\b/i,
  /\bhe\s*hits\s*me\b/i,
  /\bshe\s*hits\s*me\b/i,
  /\bthey\s*hit\s*me\b/i,
  /\bbeing\s*abused\b/i,
  /\boverdose\b/i,
  /\btake\s*my\s*own\s*life\b/i
];

export function isCrisis(text: string): boolean {
  return CRISIS_PATTERNS.some((re) => re.test(text));
}

export function crisisResponse(): GuruResponseT {
  return {
    mirror:
      "What you are carrying right now is too heavy to carry alone — and you do not have to. Please reach out to a person who can be with you in this: a trusted friend, family member, or a crisis line. In the US, call or text 988. In the UK, call 116 123 (Samaritans). Elsewhere: findahelpline.com. If you are in immediate danger, please call your local emergency number.",
    truth: "",
    action: "",
    quote: "You matter. Staying matters. The weight is real, and so is the help.",
    detected_pattern: "CRISIS",
    secondary_pattern: null,
    mode: "gentle",
    safety_route: "crisis"
  };
}
