import { z } from "zod";

/**
 * The Real Guru — shared schema.
 * Mirrors the GuruResponse schema defined in the prompt kit (§9).
 */

export const PATTERN_ENUM = [
  "VALIDATION_ADDICTION",
  "CONTROL",
  "AVOIDANCE",
  "ATTACHMENT",
  "RESENTMENT",
  "COMPARISON",
  "PERFORMANCE",
  "GRIEF",
  "FEAR",
  "LONELINESS",
  "SHAME",
  "DISTRACTION",
  "CONFUSION",
  "ENVY",
  "CRISIS"
] as const;

export const Pattern = z.enum(PATTERN_ENUM);

export const Mode = z.enum(["gentle", "real", "silent"]);

export const SafetyRoute = z.enum(["none", "crisis"]);

export const GuruResponse = z.object({
  mirror: z.string().min(1).max(800),
  truth: z.string().max(800),
  action: z.string().max(400),
  quote: z.string().max(300),
  detected_pattern: Pattern,
  secondary_pattern: Pattern.nullable().optional(),
  mode: Mode,
  safety_route: SafetyRoute
});

export type GuruResponseT = z.infer<typeof GuruResponse>;

export const GuruRequest = z.object({
  question: z.string().trim().min(1).max(2000),
  mode: Mode
});

export type GuruRequestT = z.infer<typeof GuruRequest>;
