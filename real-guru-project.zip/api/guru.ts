import Anthropic from "@anthropic-ai/sdk";
import { GuruRequest, GuruResponse, type GuruResponseT } from "./_schema";
import { MASTER_PROMPT, OVERLAYS, FEW_SHOTS, GURU_TOOL } from "./_prompt";
import { rateLimit, getClientIp } from "./_rateLimit";
import { isCrisis, crisisResponse } from "./_crisis";

/**
 * The Real Guru — main endpoint.
 *
 * POST /api/guru
 * body: { question: string, mode: "gentle" | "real" | "silent" }
 * returns: GuruResponse (see _schema.ts, also prompt-kit §9)
 */

export const config = { runtime: "edge" };

// Lazy client — the Anthropic SDK throws at construction time if the key
// is missing, which would take down the entire module. We want a graceful
// 500 with a readable error instead.
let _client: Anthropic | null = null;
function getClient(): Anthropic {
  if (!_client) _client = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });
  return _client;
}

// Rate limits per IP. Tune as needed.
const LIMITS = {
  max: Number(process.env.RATE_LIMIT_MAX || 20),
  windowMs: Number(process.env.RATE_LIMIT_WINDOW_MS || 60_000)
};

const MODEL = process.env.GURU_MODEL || "claude-sonnet-4-6";

export default async function handler(req: Request): Promise<Response> {
  // --- Method / CORS guard ---
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 204, headers: corsHeaders() });
  }
  if (req.method !== "POST") {
    return json({ error: "POST only." }, 405);
  }
  if (!process.env.ANTHROPIC_API_KEY) {
    return json({ error: "Server missing ANTHROPIC_API_KEY." }, 500);
  }

  // --- Rate limit ---
  const ip = getClientIp(req);
  const rl = rateLimit(`guru:${ip}`, LIMITS);
  if (!rl.ok) {
    return json(
      {
        error: "Too many questions. Breathe. Try again in a moment.",
        retry_after: rl.retryAfter
      },
      429,
      { "retry-after": String(rl.retryAfter) }
    );
  }

  // --- Parse + validate input ---
  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return json({ error: "Invalid JSON body." }, 400);
  }
  const parsed = GuruRequest.safeParse(body);
  if (!parsed.success) {
    return json({ error: "Bad request.", issues: parsed.error.issues }, 400);
  }
  const { question, mode } = parsed.data;

  // --- Crisis defense-in-depth (runs BEFORE the LLM) ---
  if (isCrisis(question)) {
    return json(crisisResponse(), 200);
  }

  // --- Call Claude with forced tool use for strict JSON ---
  try {
    const systemPrompt =
      MASTER_PROMPT + "\n\n" + OVERLAYS[mode] + "\n\n" + FEW_SHOTS;

    const msg = await getClient().messages.create({
      model: MODEL,
      max_tokens: 600,
      temperature: 0.85,
      system: systemPrompt,
      tools: [GURU_TOOL],
      tool_choice: { type: "tool", name: GURU_TOOL.name },
      messages: [{ role: "user", content: question }]
    });

    // Find the tool_use block the model is required to emit.
    const toolBlock = msg.content.find((b) => b.type === "tool_use");
    if (!toolBlock || toolBlock.type !== "tool_use") {
      return json(
        { error: "The guru is silent right now. Try again in a moment." },
        502
      );
    }

    const raw = toolBlock.input as Record<string, unknown>;

    // Defensive defaults
    if (typeof raw.mode !== "string") raw.mode = mode;
    if (typeof raw.safety_route !== "string") {
      raw.safety_route = raw.detected_pattern === "CRISIS" ? "crisis" : "none";
    }
    if (raw.secondary_pattern === "" || raw.secondary_pattern === undefined) {
      raw.secondary_pattern = null;
    }

    const validated = GuruResponse.safeParse(raw);
    if (!validated.success) {
      return json(
        {
          error: "Model returned malformed response.",
          issues: validated.error.issues
        },
        502
      );
    }

    // If the model flagged CRISIS, overwrite with our canned safe response.
    // We do not trust the model's crisis framing; we use ours.
    if (
      validated.data.safety_route === "crisis" ||
      validated.data.detected_pattern === "CRISIS"
    ) {
      return json(crisisResponse(), 200);
    }

    const out: GuruResponseT = validated.data;
    return json(out, 200);
  } catch (err: unknown) {
    // Never leak stack traces to users.
    console.error("guru error:", err);
    const message =
      err instanceof Anthropic.APIError
        ? "The guru is silent right now. Try again in a moment."
        : "Something is off. Breathe. Try again.";
    return json({ error: message }, 500);
  }
}

// ---------------------------------------------------------------- helpers

function corsHeaders(): Record<string, string> {
  return {
    "access-control-allow-origin": "*",
    "access-control-allow-methods": "POST, OPTIONS",
    "access-control-allow-headers": "content-type"
  };
}

function json(
  body: unknown,
  status = 200,
  extra: Record<string, string> = {}
): Response {
  return new Response(JSON.stringify(body), {
    status,
    headers: {
      "content-type": "application/json; charset=utf-8",
      "cache-control": "no-store",
      ...corsHeaders(),
      ...extra
    }
  });
}
